import React, { useState, useRef } from 'react';
import Webcam from 'react-webcam';
import { createWorker } from 'tesseract.js';
import { GoogleGenerativeAI } from '@google/generative-ai';

function Scanner() {
  const webcamRef = useRef(null);
  const fileInputRef = useRef(null);
  const [scanning, setScanning] = useState(false);
  const [result, setResult] = useState('');
  const [analysis, setAnalysis] = useState('');
  const [showWebcam, setShowWebcam] = useState(true);
  const [uploadedImage, setUploadedImage] = useState(null);
  const [error, setError] = useState('');

  const processImage = async (imageSource) => {
    setScanning(true);
    setError('');
    try {
      // Perform OCR
      const worker = await createWorker();
      await worker.loadLanguage('eng');
      await worker.initialize('eng');
      const { data: { text } } = await worker.recognize(imageSource);
      await worker.terminate();
      setResult(text);

      // Analyze with Gemini
      const apiKey = import.meta.env.VITE_GEMINI_API_KEY;
      if (!apiKey || apiKey === 'your_actual_api_key_here') {
        throw new Error('Please set a valid Gemini API key in your .env file');
      }
      
      const genAI = new GoogleGenerativeAI(apiKey);
      const model = genAI.getGenerativeModel({ model: "gemini-pro" });
      const prompt = `Analyze this text and provide insights: ${text}`;
      const response = await model.generateContent(prompt);
      const result = await response.response;
      setAnalysis(result.text());
    } catch (error) {
      console.error('Error:', error);
      setError(error.message);
      setAnalysis('');
    } finally {
      setScanning(false);
    }
  };

  const captureImage = async () => {
    const imageSrc = webcamRef.current.getScreenshot();
    await processImage(imageSrc);
  };

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = async (e) => {
        setUploadedImage(e.target.result);
        await processImage(e.target.result);
      };
      reader.readAsDataURL(file);
    }
  };

  const toggleMethod = () => {
    setShowWebcam(!showWebcam);
    setUploadedImage(null);
    setResult('');
    setAnalysis('');
    setError('');
  };

  return (
    <div className="min-h-screen bg-gray-100 p-4">
      <div className="max-w-md mx-auto bg-white rounded-xl shadow-lg overflow-hidden">
        <div className="p-4">
          <h2 className="text-2xl font-bold text-center mb-4">OCR Scanner</h2>
          
          {error && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <p className="text-red-600">{error}</p>
            </div>
          )}

          <div className="flex justify-center space-x-4 mb-6">
            <button
              onClick={toggleMethod}
              className={`px-4 py-2 rounded-lg ${
                showWebcam
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700'
              }`}
            >
              Camera
            </button>
            <button
              onClick={toggleMethod}
              className={`px-4 py-2 rounded-lg ${
                !showWebcam
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700'
              }`}
            >
              Upload
            </button>
          </div>

          <div className="relative">
            {showWebcam ? (
              <>
                <Webcam
                  ref={webcamRef}
                  screenshotFormat="image/jpeg"
                  className="w-full rounded-lg"
                />
                <button
                  onClick={captureImage}
                  disabled={scanning}
                  className="absolute bottom-4 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white px-6 py-2 rounded-full shadow-lg hover:bg-blue-700 transition-colors disabled:bg-gray-400"
                >
                  {scanning ? 'Scanning...' : 'Scan Text'}
                </button>
              </>
            ) : (
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                {uploadedImage ? (
                  <div className="relative">
                    <img
                      src={uploadedImage}
                      alt="Uploaded"
                      className="max-w-full rounded-lg mx-auto"
                    />
                    {scanning && (
                      <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-50 rounded-lg">
                        <p className="text-white">Scanning...</p>
                      </div>
                    )}
                  </div>
                ) : (
                  <>
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileUpload}
                      accept="image/*"
                      className="hidden"
                    />
                    <button
                      onClick={() => fileInputRef.current.click()}
                      className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Upload Image
                    </button>
                    <p className="mt-2 text-sm text-gray-500">
                      Supports JPG, PNG, GIF
                    </p>
                  </>
                )}
              </div>
            )}
          </div>
          
          {result && (
            <div className="mt-6">
              <h3 className="text-lg font-semibold mb-2">Scanned Text:</h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-700">{result}</p>
              </div>
            </div>
          )}
          
          {analysis && (
            <div className="mt-6">
              <h3 className="text-lg font-semibold mb-2">Analysis:</h3>
              <div className="bg-gray-50 p-4 rounded-lg">
                <p className="text-gray-700">{analysis}</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default Scanner;